"""
Archive synchronization utilities for the Unified Archive Framework.

Regenerates manifests and hash indexes for any archive type.
"""

from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

from .base_archive import BaseArchive


def regenerate_manifest(
    archive: BaseArchive,
    template_path: Optional[Path] = None
) -> Path:
    """
    Regenerate MANIFEST.md for an archive.
    
    Args:
        archive: BaseArchive instance
        template_path: Optional custom template path
        
    Returns:
        Path to the generated MANIFEST.md
    """
    if template_path is None:
        template_path = Path(__file__).parent / "archive_templates" / "manifest_template.md"
    
    # Get all data files (exclude metadata)
    all_files = archive.list_files(relative=True)
    data_files = sorted([f for f in all_files if not archive.is_metadata(f)])
    
    # Classify files
    classification = archive.classify_files()
    
    # Build file list
    file_list_lines = []
    for file in data_files:
        size = archive.get_file_size(file)
        size_kb = size / 1024
        file_list_lines.append(f"- `{file}` ({size_kb:.2f} KB)")
    
    file_list = "\n".join(file_list_lines) if file_list_lines else "No files found."
    
    # Statistics
    stats = {
        "total_files": len(data_files),
        "pdf_files": len(classification["pdf"]),
        "csv_files": len(classification["csv"]),
        "image_files": len(classification["image"]),
        "other_files": len(classification["other"]),
        "years": len(archive.list_years())
    }
    
    # Load template
    try:
        with open(template_path, "r", encoding="utf-8") as f:
            template = f.read()
    except (OSError, IOError):
        # Fallback to basic template
        template = """# Archive Manifest: {{archive_name}}

**Generated:** {{date}}

## Statistics

{{stats}}

## Files

{{file_list}}
"""
    
    # Replace placeholders
    manifest_content = template.replace("{{archive_name}}", archive.name)
    manifest_content = manifest_content.replace("{{date}}", datetime.now().isoformat())
    manifest_content = manifest_content.replace("{{file_list}}", file_list)
    
    # Format stats
    stats_text = "\n".join([f"- **{k.replace('_', ' ').title()}:** {v}" for k, v in stats.items()])
    manifest_content = manifest_content.replace("{{stats}}", stats_text)
    
    # Write manifest
    manifest_path = archive.get_manifest_path()
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with open(manifest_path, "w", encoding="utf-8") as f:
        f.write(manifest_content)
    
    return manifest_path


def regenerate_hash_index(
    archive: BaseArchive,
    template_path: Optional[Path] = None,
    algorithm: str = "sha256"
) -> Path:
    """
    Regenerate HASH_INDEX.md for an archive.
    
    Args:
        archive: BaseArchive instance
        template_path: Optional custom template path
        algorithm: Hash algorithm to use (default: sha256)
        
    Returns:
        Path to the generated HASH_INDEX.md
    """
    if template_path is None:
        template_path = Path(__file__).parent / "archive_templates" / "hash_index_template.md"
    
    # Get all data files (exclude metadata)
    all_files = archive.list_files(relative=True)
    data_files = sorted([f for f in all_files if not archive.is_metadata(f)])
    
    # Compute hashes
    hash_list_lines = ["| Hash | File |", "| ---- | ---- |"]
    for file in data_files:
        try:
            file_hash = archive.compute_file_hash(file, algorithm)
            hash_list_lines.append(f"| `{file_hash}` | `{file}` |")
        except (OSError, IOError) as e:
            hash_list_lines.append(f"| `ERROR: {str(e)}` | `{file}` |")
    
    hash_list = "\n".join(hash_list_lines)
    
    # Load template
    try:
        with open(template_path, "r", encoding="utf-8") as f:
            template = f.read()
    except (OSError, IOError):
        # Fallback to basic template
        template = """# Hash Index: {{archive_name}}

**Generated:** {{date}}
**Algorithm:** {{algorithm}}

## File Hashes

{{hash_list}}
"""
    
    # Replace placeholders
    hash_content = template.replace("{{archive_name}}", archive.name)
    hash_content = hash_content.replace("{{date}}", datetime.now().isoformat())
    hash_content = hash_content.replace("{{algorithm}}", algorithm.upper())
    hash_content = hash_content.replace("{{hash_list}}", hash_list)
    
    # Write hash index
    hash_index_path = archive.get_hash_index_path()
    hash_index_path.parent.mkdir(parents=True, exist_ok=True)
    with open(hash_index_path, "w", encoding="utf-8") as f:
        f.write(hash_content)
    
    return hash_index_path


def sync_archive(
    archive: BaseArchive,
    regenerate_manifest_file: bool = True,
    regenerate_hash_file: bool = True,
    hash_algorithm: str = "sha256"
) -> Dict[str, Any]:
    """
    Synchronize archive by regenerating manifest and hash index.
    
    Args:
        archive: BaseArchive instance
        regenerate_manifest_file: Whether to regenerate MANIFEST.md
        regenerate_hash_file: Whether to regenerate HASH_INDEX.md
        hash_algorithm: Hash algorithm for hash index
        
    Returns:
        Dictionary with sync results including paths and stats
    """
    results = {
        "archive_name": archive.name,
        "sync_time": datetime.now().isoformat(),
        "manifest_path": None,
        "hash_index_path": None,
        "stats": {}
    }
    
    # Ensure archive structure exists
    archive.ensure_structure()
    
    # Get file counts
    all_files = archive.list_files(relative=True)
    data_files = [f for f in all_files if not archive.is_metadata(f)]
    classification = archive.classify_files()
    
    results["stats"] = {
        "total_files": len(all_files),
        "data_files": len(data_files),
        "pdf_files": len(classification["pdf"]),
        "csv_files": len(classification["csv"]),
        "image_files": len(classification["image"]),
        "years": len(archive.list_years())
    }
    
    # Regenerate manifest
    if regenerate_manifest_file:
        manifest_path = regenerate_manifest(archive)
        results["manifest_path"] = str(manifest_path)
    
    # Regenerate hash index
    if regenerate_hash_file:
        hash_index_path = regenerate_hash_index(archive, algorithm=hash_algorithm)
        results["hash_index_path"] = str(hash_index_path)
    
    return results
