"""Version information for godman_ai."""

__version__ = "1.0.0"
