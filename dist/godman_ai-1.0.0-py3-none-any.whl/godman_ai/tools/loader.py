"""Tool discovery utilities (stub)."""

def discover_tools():
    """Placeholder for dynamic discovery; currently no-op."""
    return []
